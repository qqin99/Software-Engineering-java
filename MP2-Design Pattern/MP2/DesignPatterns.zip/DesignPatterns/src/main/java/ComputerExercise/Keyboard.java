package ComputerExercise;

import java.io.ByteArrayInputStream;
//import java.util.Scanner;

public class Keyboard extends ComputerPeripheral{
//@TODO: Implememnt me

    public Keyboard(Computer computer) {
        super(computer);
    }

    public String run(){
        return super.run();
    }
    //ByteArrayInputStream in = new ByteArrayInputStream("\n".getBytes());
    //System.setIn(in);
    //Scanner scanner = new Scanner(System.in);
    //String readString = scanner.nextLine();
    public String getDescription(){
        //if (readString=="\n") {
            return super.getDescription() + descriptionWithKeyboard();
        //}
      //  return super.getDescription();
    }

    private String descriptionWithKeyboard(){
        return " with keyboard";
    }
}
