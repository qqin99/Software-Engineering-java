package LoggerExercise;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Logger {
    private static Logger instance;
    /**
     * @TODO Add any necessary fields and variables.
     * Integer.parseInt(new
     *                     SimpleDateFormat("dd").format(new Date()))
     */
    private String today = (new SimpleDateFormat("MMddyyyy")).format(new Date());
    private final String logFile="log"+today+".log";
    private static Logger logger=null;
    private PrintWriter writer;

    /**
     * The constructor for SingletonLogger. Set all necessary fields.
     * This should be private
     */
    //@TODO Add constructor here
    private Logger(){
        try{
            FileWriter fw=new FileWriter(logFile);
            writer= new PrintWriter(fw,true);
        } catch (IOException E){}
    }
    /**
     * @return A Logger instance of this class.
     */
    public static Logger getInstance() {
        if(logger == null)
            logger = new Logger();
        return logger;
        //return null; //@TODO: Delete this line
    }


    /**
     *
     * @param log
     *            The Object that will be logged in the file.
     *            The Logger should logs information in a file with log[MonthDayYearOfToday].log (MMddyyyy) as file name in project root directory.
     */
    public void logInFile(Object log) {
        //@TODO: implement me
        writer.println(log);
    }
}