package AnimalExercise;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Cat extends Animal{
    //@TODO: implement me

    public Cat(String backpack) {
        super(backpack);
    }
    @Override
    public String speak(){
        return "Meow";
        }

}