package AnimalExercise;

public class Cow extends Animal{
    //@TODO: implement me
    public Cow(String backpack) {
        super(backpack);
    }
    @Override
    public String speak(){
        return "Moo";
    }
}
