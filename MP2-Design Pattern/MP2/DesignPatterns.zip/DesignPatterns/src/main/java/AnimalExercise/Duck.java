package AnimalExercise;

public class Duck extends Animal{
    //@TODO: implement me
    public Duck(String backpack) {
        super("Rice");
    }
    @Override
    public String speak(){
        return "Quack";
    }
}
